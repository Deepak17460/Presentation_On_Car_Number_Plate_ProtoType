import { Component, EventEmitter, Output } from '@angular/core';
import { FileUploadService } from './services/fileUploadService/file-upload.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'vehicle-identification';




}
